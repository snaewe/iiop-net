#include "demo.hh"
#include <stdio.h>

// ComplexOperation implementation
//
class ComplexOperations_impl:
	public POA_ComplexOperations,
	public PortableServer::RefCountServantBase
{
public:
	inline ComplexOperations_impl() {}
	virtual ~ComplexOperations_impl() {}
	virtual Complex Mul(const Complex& a, const Complex& b);
	virtual Complex Add(const Complex& a, const Complex& b);
};

Complex ComplexOperations_impl::Add(const Complex& a, const Complex& b) {
	Complex c;
	c.x = a.x+b.x;
	c.y = a.y+b.y;
	return c;
}

Complex ComplexOperations_impl::Mul(const Complex& a, const Complex& b) {
	Complex c;
	c.x = a.x*b.x - a.y*b.y;
	c.y = a.x*b.y + a.y*b.x;
	return c;
}

// Factory object implementation
//
class COFactory_impl:
	public POA_COFactory,
	public PortableServer::RefCountServantBase
{
public:
	inline COFactory_impl() {}
	virtual ~COFactory_impl() {}
	virtual ComplexOperations_ptr CreateObject();
};


static PortableServer::POA_var poa;


ComplexOperations_ptr COFactory_impl::CreateObject() {
	// Create the servant
	ComplexOperations_impl *co = new ComplexOperations_impl();

	// Register the servant
	PortableServer::ObjectId_var oid = poa->activate_object (co);

	// Get an object pointer of the servant
	ComplexOperations_ptr ptr = co->_this();
	co->_remove_ref();
	
	return ptr;
}


// Main -- launch name server, register factory
//
//

int
main (int argc, char *argv[])
{

  try {
  /*
   * Initialize the ORB
   */

  CORBA::ORB_var orb = CORBA::ORB_init (argc, argv);

  /*
   * Obtain a reference to the RootPOA and its Manager
   */

  CORBA::Object_var poaobj = orb->resolve_initial_references ("RootPOA");
  poa = PortableServer::POA::_narrow (poaobj);

  /*
   * Create a TestService object
   */

  COFactory_impl * factory = new COFactory_impl;

  /*
   * Activate the Servant
   */

  PortableServer::ObjectId_var oid = poa->activate_object (factory);
  PortableServer::POAManager_var mgr = poa->the_POAManager();


  /*
   * Get reference to store name service
   */

  CORBA::Object_var ref = poa->id_to_reference (oid.in());


  /*
   * Acquire a reference to the Naming Service
   */

  CORBA::Object_var nsobj =
    orb->resolve_initial_references ("NameService");


  CosNaming::NamingContext_var nc = 
    CosNaming::NamingContext::_narrow (nsobj);

  if (CORBA::is_nil (nc)) {
    fprintf(stderr, "oops, I cannot access the Naming Service!\n");
    return 1;
  }


  /*
   * Construct Naming Service name for our testservice
   */

  CosNaming::Name name;
  name.length (1);
  name[0].id = CORBA::string_dup ("factory");
  name[0].kind = CORBA::string_dup ("");
  
  /*
   * Store a reference in the Naming Service. 
   */

  printf("Binding Factory in the Naming Service ... \n");
  nc->rebind (name, ref);
  printf("done.\n");

  /*
   * Activate the POA and start serving requests
   */

  printf("Running.\n");

  mgr->activate ();
  orb->run();

  /*
   * Shutdown (never reached)
   */

  poa->destroy (TRUE, TRUE);
  delete factory;
  } catch(...) {
    fprintf(stderr, "Caught unknown exception.\n");
  }

  return 0;
}
