package Demo;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface ComplexOperationsHome extends EJBHome {

    /**
     * This method corresponds to the ejbCreate method in the bean
     * "IntAdderBean.java".
     * @return IntAdder
     */
    ComplexOperations create() throws CreateException, RemoteException;

}
