package Demo;

public class Complex implements java.io.Serializable {
	private double x;
	private double y;

	public Complex(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getR() {
		return Math.sqrt(x*x+y*y);
	}

	public double getAlpha() {
		return Math.acos(x/getR());
	}

}
