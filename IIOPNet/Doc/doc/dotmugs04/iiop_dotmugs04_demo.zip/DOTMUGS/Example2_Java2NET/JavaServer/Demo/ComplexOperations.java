package Demo;

import javax.ejb.*;
import java.rmi.RemoteException;

/**
 * The methods in this interface are the public face of the IntAdder-Bean.
 */
public interface ComplexOperations extends EJBObject {

    public Complex add(Complex a, Complex b) throws RemoteException;
    public Complex mul(Complex a, Complex b) throws RemoteException;

}
