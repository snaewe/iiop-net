package Demo;

import javax.ejb.CreateException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;


/**
 * IntAdderBean is a stateless Session Bean. It implements the IntAdder functionality.
 */
public class ComplexOperationsBean implements SessionBean {

    private SessionContext m_ctx;

 
    /**
     * This method is required by the EJB Specification,
     * but is not used here.
     *
     */
    public void ejbActivate() {
    }

    /**
     * This method is required by the EJB Specification,
     * but is not used here.
     *
     */
    public void ejbRemove() {
    }

    /**
     * This method is required by the EJB Specification,
     * but is not used by this example.
     *
     */
    public void ejbPassivate() {
    }

    /**
     * Sets the session context.
     *
     * @param ctx               SessionContext Context for session
     */
    public void setSessionContext(SessionContext ctx) {
        m_ctx = ctx;
    }

    /**
     * This method corresponds to the create method in the home interface
     * "TestHome.java".
     *
     */
    public void ejbCreate () throws CreateException {
        // nothing special to do here
    }

    public Complex add(Complex a, Complex b) {
        double ax = a.getX();
        double ay = a.getY();
        double bx = b.getX();
        double by = b.getY();
        return new Complex(ax+bx, ay+by);
    }

    public Complex mul(Complex a, Complex b) {
        double ax = a.getX();
        double ay = a.getY();
        double bx = b.getX();
        double by = b.getY();
        return new Complex(ax*bx-ay*by, ax*by+ay*bx);
    }

}

