using System;

namespace Demo {

    [Serializable]
    public class ComplexImpl: Complex {

        public ComplexImpl() {
        }

        public ComplexImpl(double x, double y) {
            m_x = x;
            m_y = y;
        }

	public override double x {
	    get {
		return m_x;
            }
	}

	public override double y {
	    get {
		return m_y;
            }
	}

        public override double r {
            get {
                return Math.Sqrt(x*x+y*y);
            }
        }

        public override double alpha {
            get {
                return Math.Acos(x/r);
            }
        }
    }
}
