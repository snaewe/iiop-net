Demo installation

IIOP.NET
1. IIOP.NET is present at the root of the demo package
2. compile channel with "nmake build-base"

omniORB
1. unpack omniORB zip in target directory (e.g. D:\)
2. add omniORB installation directory to the PATH
3. edit "configure.bat", set the omniORB installation directory

Editor
1. edit "configure.bat", set your prefered editor
2. set the editor to use at least 16pt fonts

Prompt
1. Copy your "VS.NET command prompt to the demo root
2. Change the font to 12x16
3. Make a shortcutto it into each single demo directory
System
1. 