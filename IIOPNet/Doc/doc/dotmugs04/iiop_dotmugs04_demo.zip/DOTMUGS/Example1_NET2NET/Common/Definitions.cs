using System;

namespace Demo {

    [Serializable]
    public struct Complex {
        public readonly double x;
        public readonly double y;

        public Complex (double x, double y) {
            this.x = x;
            this.y = y;
        }

        public double r {
            get {
                return Math.Sqrt(x*x + y*y);
            }
        }

        public double alpha {
            get {
                return Math.Acos(x/r);
            }
        }

    }

    public interface ComplexOperations {
        Complex Add (Complex a, Complex b);
        Complex Mul (Complex a, Complex b);
    }

    public interface Factory {
        ComplexOperations CreateObject();
    }
}
