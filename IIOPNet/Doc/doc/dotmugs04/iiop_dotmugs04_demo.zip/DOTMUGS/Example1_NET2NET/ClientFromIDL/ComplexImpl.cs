using System;

namespace Demo {

    [Serializable]
    public class ComplexImpl: Complex {

        public ComplexImpl() {
        }

        public ComplexImpl(double x, double y) {
            this.x = x;
            this.y = y;
        }

        public override double r {
            get {
                return Math.Sqrt(x*x+y*y);
            }
        }

        public override double alpha {
            get {
                return Math.Acos(x/r);
            }
        }
    }
}
