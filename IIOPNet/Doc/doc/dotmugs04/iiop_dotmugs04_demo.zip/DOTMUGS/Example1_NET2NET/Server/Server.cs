using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using Ch.Elca.Iiop;
using Ch.Elca.Iiop.Idl;

namespace Demo {

    class ComplexOpsImpl: MarshalByRefObject, ComplexOperations {
        public Complex Add (Complex a, Complex b) {
            Console.WriteLine("Add called");
            return new Complex(a.x+b.x, a.y+b.y);
        }

        public Complex Mul (Complex a, Complex b) {
            Console.WriteLine("Mul called");
            return new Complex(a.x*b.x - a.y*b.y, a.x*b.y + a.y+b.x);
        }
    }

    [SupportedInterface(typeof(Factory))]
    class FactoryImpl: MarshalByRefObject, Factory {
        public ComplexOperations CreateObject() {
            Console.WriteLine("new object requested");
            return new ComplexOpsImpl();
        }

        public override Object InitializeLifetimeService() {
            return null;
        }
    }

	class Server {
		[STAThread]
		static void Main(string[] args)	{
            IiopChannel chan = new IiopChannel(8088);
            ChannelServices.RegisterChannel(chan);

            RemotingConfiguration.RegisterWellKnownServiceType(
			    typeof(FactoryImpl), 
			    "Factory", 
			    WellKnownObjectMode.Singleton);
            Console.WriteLine("Press any key to terminate...");
            Console.Read();
		}
	}
}
